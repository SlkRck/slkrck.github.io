#!/usr/bin/env bash
# =============================================================================
# setup-azure-github-mirror.sh
#
# Automates the full setup of Azure DevOps as primary git repo with GitHub
# as a downstream mirror, synced via Azure Pipelines on every push.
#
# Prerequisites:
#   - Azure CLI   : https://learn.microsoft.com/en-us/cli/azure/install-azure-cli
#   - git         : https://git-scm.com/downloads
#   - Run from inside your local git repository
#
# Usage:
#   chmod +x setup-azure-github-mirror.sh
#   ./setup-azure-github-mirror.sh
# =============================================================================

set -euo pipefail

# --- Colours ---
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'

info()    { echo -e "${BLUE}  ➜ ${NC}$*"; }
success() { echo -e "${GREEN}  ✓ ${NC}$*"; }
warn()    { echo -e "${YELLOW}  ⚠ ${NC}$*"; }
error()   { echo -e "${RED}  ✗ ${NC}$*"; exit 1; }
header()  { echo -e "\n${BOLD}$*${NC}"; echo "  $(printf '─%.0s' {1..50})"; }

# =============================================================================
# 1. Prerequisites
# =============================================================================
check_prereqs() {
  header "Checking prerequisites"

  if ! git rev-parse --is-inside-work-tree &>/dev/null; then
    error "Not inside a git repository. cd into your project first."
  fi
  success "Inside a git repository."

  for cmd in az git; do
    if ! command -v "$cmd" &>/dev/null; then
      case "$cmd" in
        az)  error "Azure CLI not found. Install: https://aka.ms/installazurecliwindows (Windows) or 'brew install azure-cli' (macOS)" ;;
        git) error "git not found. Install: https://git-scm.com/downloads" ;;
      esac
    fi
    success "$cmd is available."
  done

  if ! az extension show --name azure-devops &>/dev/null 2>&1; then
    info "Installing azure-devops CLI extension..."
    az extension add --name azure-devops --only-show-errors
    success "azure-devops extension installed."
  else
    success "azure-devops CLI extension is installed."
  fi
}

# =============================================================================
# 2. Collect inputs interactively
# =============================================================================
collect_inputs() {
  header "Configuration"
  echo ""

  echo -e "  ${BOLD}Azure DevOps${NC}"
  read -rp "    Organization name  : " ADO_ORG
  read -rp "    Project name       : " ADO_PROJECT
  read -rp "    Repository name    : " ADO_REPO

  echo ""
  echo -e "  ${BOLD}GitHub${NC}"
  read -rp "    Username           : " GH_USER
  read -rp "    Repository name    : " GH_REPO

  echo ""
  echo -e "  ${BOLD}Branch${NC}"
  read -rp "    Branch name [main] : " BRANCH
  BRANCH="${BRANCH:-main}"

  ADO_ORG_URL="https://dev.azure.com/${ADO_ORG}"
  ADO_REPO_URL="${ADO_ORG_URL}/${ADO_PROJECT}/_git/${ADO_REPO}"
  GH_REPO_URL="https://github.com/${GH_USER}/${GH_REPO}.git"

  echo ""
  echo "  Will configure:"
  echo "    Source (Azure DevOps) : ${ADO_REPO_URL}"
  echo "    Mirror (GitHub)       : https://github.com/${GH_USER}/${GH_REPO}"
  echo "    Sync branch           : ${BRANCH}"
  echo ""
  read -rp "  Proceed? [Y/n] " CONFIRM
  CONFIRM="${CONFIRM:-Y}"
  [[ "$CONFIRM" =~ ^[Yy]$ ]] || { info "Aborted."; exit 0; }
}

# =============================================================================
# 3. GitHub PAT (only manual step — browser opened to exact URL)
# =============================================================================
get_github_pat() {
  header "GitHub Personal Access Token"

  PAT_URL="https://github.com/settings/tokens/new?scopes=repo&description=azure-devops-sync"

  info "Opening GitHub token creation page in your browser..."
  info "The 'repo' scope will be pre-selected."
  echo ""

  # Open browser cross-platform
  if command -v xdg-open &>/dev/null; then
    xdg-open "$PAT_URL" 2>/dev/null &
  elif command -v open &>/dev/null; then
    open "$PAT_URL"
  elif command -v start &>/dev/null; then
    start "$PAT_URL"
  else
    echo ""
    warn "Could not open a browser automatically."
    echo "  Please open this URL manually:"
    echo "  ${PAT_URL}"
  fi

  echo ""
  echo "  Steps in the browser:"
  echo "    1. Confirm 'repo' scope is checked"
  echo "    2. Set expiration as desired (90 days recommended)"
  echo "    3. Click 'Generate token'"
  echo "    4. Copy the token"
  echo ""
  read -rsp "  Paste your GitHub PAT (input hidden): " GITHUB_PAT
  echo ""

  [[ -z "$GITHUB_PAT" ]] && error "No PAT provided. Exiting."

  # Quick sanity check — classic PATs start with ghp_, fine-grained with github_pat_
  if [[ ! "$GITHUB_PAT" =~ ^gh ]]; then
    warn "Token doesn't look like a standard GitHub PAT (expected prefix: ghp_ or github_pat_)."
    warn "Continuing anyway — the pipeline run will confirm whether it's valid."
  fi

  success "PAT received."
}

# =============================================================================
# 4. Azure login
# =============================================================================
azure_login() {
  header "Azure authentication"

  if az account show &>/dev/null 2>&1; then
    ACCOUNT=$(az account show --query "user.name" -o tsv)
    success "Already logged in as: ${ACCOUNT}"
  else
    info "Not logged in — starting Azure login..."
    az login --only-show-errors
    success "Azure login successful."
  fi

  az devops configure --defaults \
    organization="$ADO_ORG_URL" \
    project="$ADO_PROJECT" 2>/dev/null

  success "Azure DevOps defaults set: org=${ADO_ORG}, project=${ADO_PROJECT}"
}

# =============================================================================
# 5. Variable Group
# =============================================================================
create_variable_group() {
  header "Azure DevOps Variable Group"

  EXISTING_ID=$(az pipelines variable-group list \
    --query "[?name=='github-sync-secrets'].id" \
    -o tsv 2>/dev/null || echo "")

  if [[ -n "$EXISTING_ID" ]]; then
    warn "Variable group 'github-sync-secrets' already exists (id: ${EXISTING_ID})."
    info "Updating GITHUB_PAT value..."
    az pipelines variable-group variable update \
      --group-id "$EXISTING_ID" \
      --name "GITHUB_PAT" \
      --value "$GITHUB_PAT" \
      --secret true \
      --only-show-errors
    VAR_GROUP_ID="$EXISTING_ID"
    success "Variable group updated."
  else
    info "Creating variable group 'github-sync-secrets'..."
    VAR_GROUP_ID=$(az pipelines variable-group create \
      --name "github-sync-secrets" \
      --variables "GITHUB_PAT=${GITHUB_PAT}" \
      --authorize true \
      --query "id" \
      --only-show-errors \
      -o tsv)

    # Mark the PAT as secret (hidden in logs)
    az pipelines variable-group variable update \
      --group-id "$VAR_GROUP_ID" \
      --name "GITHUB_PAT" \
      --secret true \
      --only-show-errors

    success "Variable group created (id: ${VAR_GROUP_ID}). GITHUB_PAT marked as secret."
  fi
}

# =============================================================================
# 6. Local git remotes
# =============================================================================
setup_git_remotes() {
  header "Local git remotes"

  CURRENT_ORIGIN=$(git remote get-url origin 2>/dev/null || echo "")

  if [[ -z "$CURRENT_ORIGIN" ]]; then
    info "No origin set — adding Azure DevOps as origin..."
    git remote add origin "$ADO_REPO_URL"

  elif [[ "$CURRENT_ORIGIN" == *"github.com"* ]]; then
    info "Current origin is GitHub — renaming to 'github', adding Azure DevOps as origin..."
    git remote rename origin github
    git remote add origin "$ADO_REPO_URL"

  elif [[ "$CURRENT_ORIGIN" == *"dev.azure.com"* ]]; then
    info "Origin already points to Azure DevOps."
    if ! git remote get-url github &>/dev/null 2>&1; then
      info "Adding 'github' remote..."
      git remote add github "$GH_REPO_URL"
    fi

  else
    warn "Origin points to an unrecognised URL: ${CURRENT_ORIGIN}"
    info "Adding Azure DevOps as a second remote named 'azure'..."
    git remote add azure "$ADO_REPO_URL"
  fi

  echo ""
  success "Remotes:"
  git remote -v | sed 's/^/    /'
}

# =============================================================================
# 7. Pipeline YAML
# =============================================================================
create_pipeline_yaml() {
  header "Pipeline YAML"

  YAML_DIR=".azure-pipelines"
  YAML_FILE="${YAML_DIR}/sync-to-github.yml"

  mkdir -p "$YAML_DIR"

  cat > "$YAML_FILE" << YAML
trigger:
  branches:
    include:
      - ${BRANCH}

pool:
  vmImage: 'ubuntu-latest'

variables:
  - group: github-sync-secrets

steps:
  - checkout: self
    fetchDepth: 0
    persistCredentials: true

  - script: |
      git config user.email "azure-sync@noreply.com"
      git config user.name "Azure DevOps Sync"
      git remote add github \\
        https://\$(GITHUB_PAT)@github.com/${GH_USER}/${GH_REPO}.git
      git push github HEAD:${BRANCH} --force-with-lease
    displayName: 'Mirror to GitHub'
YAML

  success "Pipeline YAML written to ${YAML_FILE}"
}

# =============================================================================
# 8. Commit and push the YAML
# =============================================================================
commit_and_push() {
  header "Committing pipeline file"

  git add .azure-pipelines/sync-to-github.yml

  if git diff --cached --quiet; then
    warn "Pipeline file already committed — nothing to commit."
  else
    git commit -m "ci: add GitHub mirror sync pipeline [skip ci]"
    success "Committed pipeline file."
  fi

  info "Pushing to Azure DevOps (origin ${BRANCH})..."
  git push origin "${BRANCH}"
  success "Pushed to Azure DevOps."
}

# =============================================================================
# 9. Register the pipeline in Azure DevOps
# =============================================================================
register_pipeline() {
  header "Registering pipeline"

  EXISTING_PIPELINE=$(az pipelines list \
    --query "[?name=='Mirror to GitHub'].id" \
    -o tsv 2>/dev/null || echo "")

  if [[ -n "$EXISTING_PIPELINE" ]]; then
    warn "Pipeline 'Mirror to GitHub' already exists (id: ${EXISTING_PIPELINE}). Skipping creation."
    PIPELINE_ID="$EXISTING_PIPELINE"
  else
    info "Creating pipeline 'Mirror to GitHub'..."
    PIPELINE_ID=$(az pipelines create \
      --name "Mirror to GitHub" \
      --repository "$ADO_REPO" \
      --repository-type tfsgit \
      --branch "$BRANCH" \
      --yml-path ".azure-pipelines/sync-to-github.yml" \
      --skip-first-run true \
      --only-show-errors \
      --query "id" -o tsv)
    success "Pipeline created (id: ${PIPELINE_ID})."
  fi
}

# =============================================================================
# 10. Trigger and monitor the first run
# =============================================================================
run_and_verify() {
  header "Running pipeline — first sync to GitHub"

  RUN_ID=$(az pipelines run \
    --name "Mirror to GitHub" \
    --branch "$BRANCH" \
    --only-show-errors \
    --query "id" -o tsv)

  info "Pipeline run started (run id: ${RUN_ID}). Polling for result..."
  echo -n "  "

  for _ in {1..36}; do   # max ~6 minutes
    STATUS=$(az pipelines runs show --id "$RUN_ID" --query "status" -o tsv 2>/dev/null)
    RESULT=$(az pipelines runs show --id "$RUN_ID" --query "result" -o tsv 2>/dev/null)

    if [[ "$STATUS" == "completed" ]]; then
      echo ""
      if [[ "$RESULT" == "succeeded" ]]; then
        success "Pipeline run succeeded. GitHub is now in sync."
      else
        echo ""
        error "Pipeline run finished with result: ${RESULT}
  Check the logs at:
  ${ADO_ORG_URL}/${ADO_PROJECT}/_build/results?buildId=${RUN_ID}

  Common causes:
    - GitHub PAT lacks 'repo' scope   → regenerate and update the Variable Group
    - GitHub repo name/username typo  → re-run this script
    - GitHub repo doesn't exist yet   → create it first (can be empty)"
      fi
      return
    fi

    echo -n "."
    sleep 10
  done

  echo ""
  warn "Timed out waiting for pipeline to complete."
  info "Check status at: ${ADO_ORG_URL}/${ADO_PROJECT}/_build/results?buildId=${RUN_ID}"
}

# =============================================================================
# 11. Summary
# =============================================================================
print_summary() {
  echo ""
  echo -e "${GREEN}${BOLD}  ══════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}${BOLD}  Setup complete!${NC}"
  echo -e "${GREEN}${BOLD}  ══════════════════════════════════════════════════${NC}"
  echo ""
  echo "  Source of truth  : ${ADO_REPO_URL}"
  echo "  GitHub mirror    : https://github.com/${GH_USER}/${GH_REPO}"
  echo "  Sync pipeline    : Mirror to GitHub  (triggers on push to ${BRANCH})"
  echo ""
  echo "  Your workflow from now on:"
  echo ""
  echo "    git add / git commit"
  echo "    git push origin ${BRANCH}    ← GitHub updates automatically"
  echo ""
  echo "  Use Azure DevOps for: Boards, PRs, Work Items, Pipelines"
  echo "  Use GitHub for:       Portfolio, open-source visibility, backup"
  echo ""
}

# =============================================================================
# Main
# =============================================================================
main() {
  echo ""
  echo -e "${BOLD}  Azure DevOps → GitHub Mirror Setup${NC}"
  echo "  $(printf '═%.0s' {1..50})"

  check_prereqs
  collect_inputs
  get_github_pat
  azure_login
  create_variable_group
  setup_git_remotes
  create_pipeline_yaml
  commit_and_push
  register_pipeline
  run_and_verify
  print_summary
}

main
